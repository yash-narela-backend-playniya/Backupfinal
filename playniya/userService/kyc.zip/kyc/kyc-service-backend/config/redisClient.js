const redis = require('redis');

const client = redis.createClient({
  url: process.env.REDIS || "redis://localhost:6379",
});

client.connect().catch(err => {
    console.error('Failed to connect to Redis ❌', err);
  });


module.exports = client;
