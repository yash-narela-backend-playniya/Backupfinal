const { createProducer } = require("../kafka/index.js");
const {
  verifyEmailOTP,
  sendEmailOTP,
} = require("../services/emailServices.js");
const User = ""; // Make sure this path is correct
const redisClient = require("../config/redisClient");


let producer;

(async () => {
  producer = await createProducer();
  await producer.connect();
  console.log("🟢 Kafka producer connected");
})().catch(err => {
  console.error("❌ Failed to initialize Kafka producer:", err);
});

exports.sendAadharOTP = async (req, res) => {
  const { aadhar } = req.body;
  if (!aadhar) {
    return res
      .status(400)
      .json({ success: false, message: "Aadhar number is required" });
  }

  try {
    return res
      .status(200)
      .json({ success: true, message: "OTP sent to registered Aadhar mobile" });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Something went wrong" });
  }
};

exports.verifyAadharOTP = async (req, res) => {
  const { aadhar, otp } = req.body;
  if (!aadhar || !otp) {
    return res
      .status(400)
      .json({ success: false, message: "Aadhar and OTP are required" });
  }

  try {
    
    const userId = req.user.userId;

    await producer.send({
      topic: "kyc.aadhar.pending",
      messages: [{ key: userId, value: JSON.stringify({ userId }) }],
    });
    console.log("KYC pending message sent...");


    await producer.send({
      topic: "kyc.aadhar.verified",
      messages: [{ key: userId, value: JSON.stringify({ userId, aadhar }) }],
    });

    return res
      .status(200)
      .json({ success: true, message: "Aadhar verified successfully!" });
  } catch (err) {
    console.error("Error verifying Aadhar:", err);
    return res
      .status(500)
      .json({ success: false, message: "Failed to verify Aadhar" });
  }
};

exports.sendPanOTP = async (req, res) => {
  const { pan } = req.body;
  if (!pan) {
    return res
      .status(400)
      .json({ success: false, message: "PAN number is required" });
  }

  try {
    return res
      .status(200)
      .json({ success: true, message: "OTP sent to registered PAN mobile" });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Something went wrong" });
  }
};

exports.verifyPanOTP = async (req, res) => {
  const { pan, otp } = req.body;
  if (!pan || !otp) {
    return res
      .status(400)
      .json({ success: false, message: "PAN and OTP are required" });
  }

  try {
    const userId = req.user.userId
    
    await producer.send({
      topic: "kyc.pan.verified",
      messages: [{ key: userId, value: JSON.stringify({ userId, pan }) }],
    });

    return res
      .status(200)
      .json({ success: true, message: "PAN verified successfully!" });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Failed to verify PAN" });
  }
};

exports.sendTruecallerOTP = async (req, res) => {
  const { phone } = req.body;
  if (!phone) {
    return res
      .status(400)
      .json({ success: false, message: "Phone number is required" });
  }

  try {
    return res
      .status(200)
      .json({ success: true, message: "OTP sent to Truecaller phone" });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Something went wrong" });
  }
};

exports.verifyTruecallerOTP = async (req, res) => {
  const { phone, otp } = req.body;
  if (!phone || !otp) {
    return res.status(400).json({
      success: false,
      message: "Phone and OTP are required",
    });
  }

  try {
    const userId = req.user.userId
    
    await producer.send({
      topic: "kyc.truecaller.verified",
      messages: [{ key: userId, value: JSON.stringify({ userId, phone }) }],
    });

    return res
      .status(200)
      .json({ success: true, message: "Truecaller verified successfully!" });
  } catch (err) {
    return res
      .status(500)
      .json({ success: false, message: "Failed to verify Truecaller" });
  }
};

exports.sendEmail = async (req, res) => {
  const { email } = req.body;
  try {
    await sendEmailOTP(email);
    res.json({ success: true, message: "OTP sent to email" });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.verifyEmail = async (req, res) => {
  const { email, otp } = req.body;

  try {
    const isValid = await verifyEmailOTP(email, otp);

    if (isValid) {
      
      const userId = req.user.userId
      await producer.send({
        topic: "kyc.email.verified",
        messages: [{ key: userId, value: JSON.stringify({ userId, email }) }],
      });
      await redisClient.del(`email_otp_${email}`);

      res.json({ success: true, message: "Email verified successfully" });
    } else {
      res.json({ success: false, message: "Invalid or expired OTP" });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
