async function kycSandbox(aadhar, otp) {
  await new Promise((resolve) => setTimeout(resolve, 1000));
  if (otp % 2 === 0) return true;
  return false;
}
