const nodemailer = require('nodemailer');
const client = require('../config/redisClient');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: parseInt(process.env.EMAIL_PORT),
  secure: true, 
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  },
  tls: {
    rejectUnauthorized: false 
  }
});


function generateOTP(length = 6) {
  const min = Math.pow(10, length - 1);
  const max = Math.pow(10, length) - 1;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

exports.sendEmailOTP = async (email) => {
  const otp = generateOTP().toString();
  const key = `email_otp:${email}`;
  const limitKey = `email_otp_limit:${email}`;

  const attempts = await client.get(limitKey);
  if (attempts && parseInt(attempts) >= 10) {
    throw new Error('Too many requests. Try again later.');
  }

  await client.setEx(key, 600, otp); // 10 mins
  await client.incr(limitKey);
  await client.expire(limitKey, 900);

  await transporter.sendMail({
    from: `"OTP Service" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Your OTP Code',
    text: `Your verification code is: ${otp}`,
  });

  return true;
};

exports.verifyEmailOTP = async (email, otp) => {
  const key = `email_otp:${email}`;
  const storedOTP = await client.get(key);
  if (storedOTP !== otp) {
      return false;
    }
    
    await client.del(key);
    return true;
};
