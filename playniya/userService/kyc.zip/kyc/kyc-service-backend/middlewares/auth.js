const jwt = require('jsonwebtoken');
const JWT_SECRET = process.env.JWT_SECRET;

const { AppError } = require("../utlility/apiError")
const {ApiError} = require("../utlility/apiError")

const { ApiResponse } = require("../utlility/apiResponse.js")



const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return next(new ApiError(401, "Authorization header missing or malformed"));
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    req.token = token;
    next();
  } catch (err) {
    return next(new ApiError(401, "Invalid or expired token", [], err.stack));
  }
};

module.exports = authenticate;