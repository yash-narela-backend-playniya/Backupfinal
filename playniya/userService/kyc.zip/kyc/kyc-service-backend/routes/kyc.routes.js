const express = require("express");
const {
  sendEmail,
  verifyEmail,
  sendPanOTP,
  verifyAadharOTP,
  sendAadharOTP,
  verifyPanOTP,
  verifyTruecallerOTP,
  sendTruecallerOTP,
} = require("../controllers/kyc.controller.js");
const router = express.Router();
const auth = require("../middlewares/auth.js");

router.post("/send-email", auth, sendEmail);
router.post("/verify-email", auth, verifyEmail);
router.post("/sendAadharOTP", auth, sendAadharOTP);
router.post("/verifyAadharOTP", auth, verifyAadharOTP);
router.post("/sendPanOTP", auth, sendPanOTP);
router.post("/verifyPanOTP", auth, verifyPanOTP);
router.post("/sendTruecallerOTP", auth, sendTruecallerOTP);
router.post("/verifyTruecallerOTP", auth, verifyTruecallerOTP);

module.exports = router;

