require('dotenv').config()
const express = require('express')
const morgan = require('morgan')
const cors = require('cors')
const helmet = require('helmet')


const app = express()
app.use(express.json());
app.use(morgan("dev"));
app.use(helmet());
app.use(cors({
    origin: process.env.CORS_ORIGIN || '*',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
  }));

app.use("/kyc", require("./routes/kyc.routes"))

const PORT = process.env.PORT || 5002

app.listen(PORT, ()=>{
    console.log("server is running")
})
