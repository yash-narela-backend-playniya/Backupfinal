const { Kafka } = require("kafkajs");

const kafka = new Kafka({
  clientId: "kyc-service",
  brokers: ["localhost:9092"],
});

const createConsumer = async (groupId) => {
  return kafka.consumer({ groupId });
}

const createProducer = async() => {
  return kafka.producer();
}

module.exports = { createProducer, createConsumer };
