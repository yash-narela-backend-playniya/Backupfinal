const { Kafka } = require("kafkajs");

const kafka = new Kafka({
  clientId: "kyc_verification",
  brokers: ["localhost: 9092"],
});

const producer = await kafka.producer()
await producer.connect()

module.exports={producer}
