// kafka/consumer.js

const { createConsumer, createProducer } = require("./index");
const client = require("../config/redisClient");

let consumer;
let producer;

const start = async () => {
  consumer = await createConsumer("kyc-group");
  producer = await createProducer();

  await consumer.connect();
  await producer.connect();

  await consumer.subscribe({ topic: "kyc.aadhar.pending" });
  await consumer.subscribe({ topic: "kyc.pan.verified" });
  await consumer.subscribe({ topic: "kyc.email.verified"})
  await consumer.subscribe({ topic: "kyc.truecaller.verified"})

  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      const value = message.value.toString();
      try {
        const data = JSON.parse(value);

        if (topic === "kyc.aadhar.pending") {
          console.log("Received KYC pending state", data);
          await client.set(`user:${data.userId}`, JSON.stringify(data), { EX: 300 });
          console.log("Data cached successfully");
        }

        else if (topic === "kyc.aadhar.verified") {
          console.log("Received KYC verified state", data)
          await producer.send({
            topic: "user.update.aadhar",
            messages: [
              {
                key: data.userId,
                value: JSON.stringify({
                  userId: data.userId,
                  updates: {
                    aadharNumber: data.aadhar,
                    isAadharVerified: true,
                  },
                }),
              },
            ],
          });

          console.log("Sent user.update event");
        } else if (topic === "kyc.aadhar.successful"){
          console.log("user's info update successfully")
          await client.del(`user:${data.userId}`);
          console.log("Cache deleted for user");
        } else if(topic === "kyc.pan.verified"){
          console.log("request to update the user's pan received")
          await producer.send({
            topic: "user.update.pan",
            messages: [
              {
                key: data.userId,
                value: JSON.stringify({
                  userId: data.userId,
                  updates: {
                    aadharNumber: data.pan,
                    isPanVerified: true,
                  },
                }),
              },
            ],
          });
          
        } else if (topic === "kyc.pan.successful"){
          console.log("User's pan verified")
        } else if(topic === "kyc.email.verified") {
          console.log("request to update the user email received")
          await producer.send({
            topic: "user.update.email",
            messages: [
              {
                key: data.userId,
                value: JSON.stringify({
                  userId: data.userId,
                  updates: {
                    email: data.email,
                    isEmailVerified: true,
                  },
                }),
              },
            ],
          });
        } else if(topic === "kyc.email.successful"){
          console.log("user's email verified")
        } else if (topic === "kyc.truecaller.verified"){
          console.log("request to update the truecaller received")
          await producer.send({
            topic: "user.update.truecaller",
            messages: [
              {
                key: data.userId,
                value: JSON.stringify({
                  userId: data.userId,
                  updates: {
                    phone: data.phone,
                    isTruecallerVerified: true,
                  },
                }),
              },
            ],
          })
        } else if (topic === "kyc.truecaller.successful") {
          console.log("kyc request for truecaller done!")
        }

      } catch (error) {
        console.error(`Failed to process message on topic ${topic}`, error);
      }
    },
  });

  console.log("Kafka consumer started and listening to topics...");
};

start().catch((err) => {
  console.error("Error starting Kafka consumers:", err);
});
