// 
// THIS FILE HAS BEEN GENERATED AUTOMATICALLY
// DO NOT CHANGE IT MANUALLY UNLESS YOU KNOW WHAT YOU'RE DOING
// 
// GENERATED USING @colyseus/schema 3.0.33
// 

namespace MyGame.Schema {
	public struct PieceType {

		public const string WHITE = "white";
		public const string BLACK = "black";
		public const string QUEEN = "queen";
		public const string STRIKER = "striker";
	}
}